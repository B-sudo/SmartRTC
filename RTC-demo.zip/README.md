npm init -y

npm install ws

npm install express --save
